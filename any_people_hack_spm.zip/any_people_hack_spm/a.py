import os, sys, time, json, ssl, socket, threading, asyncio, base64, binascii, re, jwt, pickle
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
from threading import Thread

import requests
import aiohttp
import urllib3
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
from google.protobuf.timestamp_pb2 import Timestamp
from protobuf_decoder.protobuf_decoder import Parser

# custom project modules (assumed available)
from byte import *
from byte import xSEndMsg, Auth_Chat
from xHeaders import *
from black9 import openroom, spmroom
import xKEys

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# -------------------------------------------------------------------
# Global state & thread‑safe access
# -------------------------------------------------------------------
connected_clients = {}
connected_clients_lock = threading.Lock()
active_power_targets = {}
active_power_lock = threading.Lock()
spam_running = False
spam_thread = None

C = "\033[96m"
G = "\033[92m"
Y = "\033[93m"
R = "\033[91m"
RS = "\033[0m"
BOLD = "\033[1m"

# -------------------------------------------------------------------
# Protobuf helpers (same as original)
# -------------------------------------------------------------------
def _rdVr(data, pos):
    n = 0; sh = 0
    while True:
        b = data[pos]; pos += 1
        n |= (b & 0x7F) << sh; sh += 7
        if not b & 0x80: break
    return n, pos

def _pbF(data):
    out = {}; pos = 0
    while pos < len(data):
        try:
            tag, pos = _rdVr(data, pos)
            fn = tag >> 3; wt = tag & 0x7
            if wt == 0:
                v, pos = _rdVr(data, pos); out[fn] = v
            elif wt == 2:
                ln, pos = _rdVr(data, pos); out[fn] = data[pos:pos+ln]; pos += ln
            elif wt == 1:
                out[fn] = data[pos:pos+8]; pos += 8
            elif wt == 5:
                out[fn] = data[pos:pos+4]; pos += 4
            else: break
        except: break
    return out

async def _vr(n):
    h = []
    while True:
        b = n & 0x7F; n >>= 7
        if n: b |= 0x80
        h.append(b)
        if not n: break
    return bytes(h)

async def _enc(hx, k, v):
    return AES.new(k, AES.MODE_CBC, v).encrypt(pad(bytes.fromhex(hx), 16)).hex()

async def _hx(n):
    f = hex(n)[2:]
    return ('0' + f) if len(f) == 1 else f

async def _var(fn, val):
    return await _vr((fn << 3) | 0) + await _vr(val)

async def _len(fn, val):
    e = val.encode() if isinstance(val, str) else val
    return await _vr((fn << 3) | 2) + await _vr(len(e)) + e

async def _pb(flds):
    p = bytearray()
    for f, v in flds.items():
        if isinstance(v, dict): p.extend(await _len(f, await _pb(v)))
        elif isinstance(v, int): p.extend(await _var(f, v))
        elif isinstance(v, (str, bytes)): p.extend(await _len(f, v))
    return p

async def _pk(px, n, k, v):
    e = await _enc(px, k, v)
    _ = await _hx(len(e) // 2)
    m = {2:'000000', 3:'00000', 4:'0000', 5:'000'}
    return bytes.fromhex(n + m.get(len(_), '000000') + _ + e)

async def _mkLogin(oid, atk):
    return await _pb({
        3: str(datetime.now())[:-7], 4: 'free fire', 5: 1, 7: '1.123.1',
        8: 'Android OS 9 / API-28 (PQ3B.190801.10101846/G9650ZHU2ARC6)',
        9: 'Handheld', 10: 'Verizon', 11: 'WIFI', 12: 1920, 13: 1080,
        14: '280', 15: 'ARM64 FP ASIMD AES VMH | 2865 | 4', 16: 3003,
        17: 'Adreno (TM) 640', 18: 'OpenGL ES 3.1 v1.46',
        19: 'Google|34a7dcdf-a7d5-4cb6-8d7e-3b0e448a0c57',
        20: '223.191.51.89', 21: 'en', 22: oid, 23: '4', 24: 'Handheld',
        25: {6: 55, 8: 81},
        29: atk, 30: 1, 73: 3, 78: 3, 79: 2, 81: '64',
        93: 'android', 97: 1, 98: 1, 99: '4', 100: '4',
    })

async def _auth(uid, tok, ts, k, v):
    uh = hex(uid)[2:]
    hd = {9:'0000000',8:'00000000',10:'000000',7:'000000000'}.get(len(uh),'0000000')
    e = await _enc(tok.encode().hex(), k, v)
    el = await _hx(len(e) // 2)
    return f"0115{hd}{uh}{await _hx(ts)}00000{el}{e}"

# -------------------------------------------------------------------
# Spam worker – sends the same packets as the original working code
# -------------------------------------------------------------------
def spam_worker(target_id, duration_minutes=None):
    global spam_running

    print(f"\n{C}{'='*60}{RS}")
    print(f"{G}🎯 SPAM STARTED ON: {BOLD}{target_id}{RS}")
    print(f"{Y}⏱️ Mode: Round Robin – 10 requests/account, 2 s gap between accounts{RS}")
    print(f"{Y}⏱️ Duration: {duration_minutes if duration_minutes else 'UNLIMITED'} minutes{RS}")
    print(f"{C}{'='*60}{RS}\n")

    start_time = datetime.now()
    total_requests = 0
    round_number = 0

    while spam_running:
        with active_power_lock:
            if target_id not in active_power_targets:
                break

        with connected_clients_lock:
            clients_list = list(connected_clients.values())

        if not clients_list:
            print(f"{Y}[!] No online accounts, waiting...{RS}")
            time.sleep(2)
            continue

        round_number += 1
        round_requests = 0

        print(f"\n{C}{'─'*50}{RS}")
        print(f"{G}🔄 ROUND #{round_number} STARTING{RS}")
        print(f"{C}{'─'*50}{RS}")

        for idx, client in enumerate(clients_list, 1):
            if not spam_running:
                break

            account_id = getattr(client, 'id', 'Unknown')
            print(f"\n{Y}[▶] Account {idx}/{len(clients_list)}: {account_id}{RS}")

            # --- FIX: first send openroom, then spam packets (same logic as original) ---
            try:
                # Step 1 – openroom packet (needed by server to process spam)
                if (hasattr(client, 'CliEnts2') and client.CliEnts2 and
                    hasattr(client, 'key') and client.key and
                    hasattr(client, 'iv') and client.iv):

                    try:
                        open_pkt = openroom(client.key, client.iv)
                        if open_pkt:
                            client.CliEnts2.send(open_pkt)
                    except Exception:
                        pass  # non‑fatal, continue with spmroom
                else:
                    print(f"    └─ ⚠️ Client missing CliEnts2/key/iv, skipping")
                    continue

                # Step 2 – send 10 spmroom requests
                acc_requests = 0
                for i in range(1, 11):
                    if not spam_running:
                        break
                    try:
                        spam_pkt = spmroom(client.key, client.iv, target_id)
                        if spam_pkt:
                            client.CliEnts2.send(spam_pkt)
                            total_requests += 1
                            round_requests += 1
                            acc_requests += 1
                            print(f"    ├─ [{i:2d}] ✅ Request sent | Total: {total_requests}", end='\r')
                    except (BrokenPipeError, ConnectionResetError, OSError):
                        # socket dead → remove from connected list and stop sending for this client
                        with connected_clients_lock:
                            if account_id in connected_clients:
                                del connected_clients[account_id]
                        print(f"\n    ├─ [{i:2d}] ❌ Connection lost, client removed")
                        break
                    except Exception as e:
                        print(f"\n    ├─ [{i:2d}] ❌ Failed: {e}")
                        break

                print(f"\n    └─ ✅ Done: {acc_requests}/10 sent")
            except Exception as e:
                print(f"    └─ ❌ Error: {e}")

            # Short gap before moving to the next account (not after last one)
            if idx < len(clients_list) and spam_running:
                for wait in range(2, 0, -1):
                    if not spam_running:
                        break
                    print(f"    ⏳ Next account in {wait} s...", end='\r')
                    time.sleep(1)
                print("    ⏳ Ready                           ")

        # Round summary
        print(f"\n{C}{'─'*50}{RS}")
        print(f"{G}📊 ROUND #{round_number} COMPLETED")
        print(f"   📨 Requests this round: {round_requests}")
        print(f"   📊 Total requests: {total_requests}")
        print(f"   👥 Online accounts: {len(clients_list)}")
        print(f"{C}{'─'*50}{RS}\n")

        # Duration check
        if duration_minutes:
            elapsed = (datetime.now() - start_time).total_seconds()
            if elapsed >= duration_minutes * 60:
                print(f"\n{R}{'='*50}{RS}")
                print(f"{R}⏰ TIME FINISHED!{RS}")
                print(f"{G}📊 Total requests sent: {BOLD}{total_requests}{RS}")
                print(f"{R}{'='*50}{RS}\n")
                with active_power_lock:
                    if target_id in active_power_targets:
                        del active_power_targets[target_id]
                break

        # Small pause between rounds
        time.sleep(0.5)

    print(f"\n{R}{'='*50}{RS}")
    print(f"{R}🛑 SPAM STOPPED ON: {target_id}{RS}")
    print(f"{G}📊 FINAL TOTAL: {total_requests} requests{RS}")
    print(f"{R}{'='*50}{RS}\n")

def start_power(target_id, duration_minutes=None):
    global spam_running, spam_thread

    with active_power_lock:
        if target_id in active_power_targets:
            print(f"{Y}⚠️ Already spamming on: {target_id}{RS}")
            return
        active_power_targets[target_id] = {
            'active': True,
            'start_time': datetime.now(),
            'duration': duration_minutes,
        }

    spam_running = True
    spam_thread = Thread(target=spam_worker, args=(target_id, duration_minutes), daemon=True)
    spam_thread.start()
    print(f"{G}✅ Spam started on: {target_id}{RS}")

def stop_power(target_id):
    global spam_running

    with active_power_lock:
        if target_id in active_power_targets:
            del active_power_targets[target_id]
            spam_running = False
            print(f"{R}🛑 Spam stopped: {target_id}{RS}")
        else:
            print(f"{Y}⚠️ No active spam on: {target_id}{RS}")

# -------------------------------------------------------------------
# Auto‑restart helpers
# -------------------------------------------------------------------
def AuTo_ResTartinG():
    time.sleep(6 * 60 * 60)
    print(f'\n{Y}🔄 Auto Restarting Bot...{RS}')
    p = psutil.Process(os.getpid())
    for handler in p.open_files():
        try: os.close(handler.fd)
        except: pass
    for conn in p.net_connections():
        try:
            if hasattr(conn, 'fd'): os.close(conn.fd)
        except: pass
    sys.path.append(os.path.dirname(os.path.abspath(sys.argv[0])))
    python = sys.executable
    os.execl(python, python, *sys.argv)

def ResTarT_BoT():
    print(f'\n{Y}🔄 Restarting Bot...{RS}')
    p = psutil.Process(os.getpid())
    for handler in p.open_files():
        try: os.close(handler.fd)
        except: pass
    for conn in p.net_connections():
        try: conn.close()
        except: pass
    sys.path.append(os.path.dirname(os.path.abspath(sys.argv[0])))
    python = sys.executable
    os.execl(python, python, *sys.argv)

Thread(target=AuTo_ResTartinG, daemon=True).start()

# -------------------------------------------------------------------
# Account loading
# -------------------------------------------------------------------
ACCOUNTS = []

def load_accounts_from_file(filename="accs.txt"):
    accounts = []
    try:
        with open(filename, "r", encoding="utf-8") as file:
            for line in file:
                line = line.strip()
                if line and not line.startswith("#"):
                    if ":" in line:
                        parts = line.split(":")
                        if len(parts) >= 2:
                            accounts.append({'id': parts[0].strip(), 'password': parts[1].strip()})
                    else:
                        accounts.append({'id': line.strip(), 'password': ''})
        print(f"{G}📦 Loaded {len(accounts)} accounts from {filename}{RS}")
    except FileNotFoundError:
        print(f"{Y}⚠️ {filename} not found! Creating demo file...{RS}")
        with open(filename, "w", encoding="utf-8") as f:
            f.write("# accs.txt - Format: UID:PASSWORD\n")
            f.write("4575104506:TORIKUL_TORIKUL_E6H3H\n")
        print(f"{G}✅ Created {filename}{RS}")
        return load_accounts_from_file(filename)
    except Exception as e:
        print(f"{R}❌ Error reading file: {e}{RS}")
    return accounts

ACCOUNTS = load_accounts_from_file()

# -------------------------------------------------------------------
# FF Client – unchanged from the provided second file
# -------------------------------------------------------------------
class FF_CLient():
    def __init__(self, id, password):
        self.id = id
        self.password = password
        self.key = None
        self.iv = None
        self.Get_FiNal_ToKen_0115()

    def Connect_SerVer_OnLine(self, Token, tok, host, port, key, iv, host2, port2):
        try:
            self.AutH_ToKen_0115 = tok    
            self.CliEnts2 = socket.create_connection((host2, int(port2)))
            self.CliEnts2.send(bytes.fromhex(self.AutH_ToKen_0115))
            
            with connected_clients_lock:
                if self.id not in connected_clients:
                    connected_clients[self.id] = self
                    print(f"{G}✅ Online: {self.id} (Total: {len(connected_clients)}){RS}")
        except Exception as e:
            print(f"{R}❌ Online error {self.id}: {e}{RS}")
            return
        
        while True:
            try:
                self.DaTa2 = self.CliEnts2.recv(99999)
                if '0500' in self.DaTa2.hex()[0:4] and len(self.DaTa2.hex()) > 30:
                    self.packet = json.loads(DeCode_PackEt(f'08{self.DaTa2.hex().split("08", 1)[1]}'))
                    self.AutH = self.packet['5']['data']['7']['data']
            except: pass
                                                            
    def Connect_SerVer(self, Token, tok, host, port, key, iv, host2, port2):
        self.AutH_ToKen_0115 = tok    
        self.CliEnts = socket.create_connection((host, int(port)))
        self.CliEnts.send(bytes.fromhex(self.AutH_ToKen_0115))  
        self.DaTa = self.CliEnts.recv(1024)          	        
        threading.Thread(target=self.Connect_SerVer_OnLine, args=(Token, tok, host, port, key, iv, host2, port2)).start()
        
        try: self.Exemple = xMsGFixinG('12345678')
        except: pass
        
        self.key = key
        self.iv = iv
        
        with connected_clients_lock:
            if self.id not in connected_clients:
                connected_clients[self.id] = self
                print(f"{G}✅ Registered: {self.id}{RS}")
        
        while True:      
            try:
                self.DaTa = self.CliEnts.recv(1024)   
                if len(self.DaTa) == 0 or (hasattr(self, 'DaTa2') and len(self.DaTa2) == 0):
                    try:
                        self.CliEnts.close()
                        if hasattr(self, 'CliEnts2'): self.CliEnts2.close()
                        self.Connect_SerVer(Token, tok, host, port, key, iv, host2, port2)                    		                    
                    except:
                        try:
                            self.CliEnts.close()
                            if hasattr(self, 'CliEnts2'): self.CliEnts2.close()
                            self.Connect_SerVer(Token, tok, host, port, key, iv, host2, port2)
                        except:
                            self.CliEnts.close()
                            if hasattr(self, 'CliEnts2'): self.CliEnts2.close()
                            ResTarT_BoT()	            
            except Exception as e:
                print(f"{R}❌ Connection error {self.id}: {e}{RS}")
                with connected_clients_lock:
                    if self.id in connected_clients: del connected_clients[self.id]
                self.Connect_SerVer(Token, tok, host, port, key, iv, host2, port2)
                                    
    def GeT_Key_Iv(self, serialized_data):
        my_message = xKEys.MyMessage()
        my_message.ParseFromString(serialized_data)
        timestamp, key, iv = my_message.field21, my_message.field22, my_message.field23
        timestamp_obj = Timestamp()
        timestamp_obj.FromNanoseconds(timestamp)
        timestamp_seconds = timestamp_obj.seconds
        timestamp_nanos = timestamp_obj.nanos
        combined_timestamp = timestamp_seconds * 1_000_000_000 + timestamp_nanos
        return combined_timestamp, key, iv    

    def Guest_GeneRaTe(self, uid, password):
        self.url = "https://100067.connect.garena.com/oauth/guest/token/grant"
        self.headers = {
            "Host": "100067.connect.garena.com",
            "User-Agent": "GarenaMSDK/4.0.19P4(G011A ;Android 9;en;US;)",
            "Content-Type": "application/x-www-form-urlencoded",
            "Accept-Encoding": "gzip, deflate, br",
            "Connection": "close",
        }
        self.dataa = {
            "uid": f"{uid}",
            "password": f"{password}",
            "response_type": "token",
            "client_type": "2",
            "client_secret": "2ee44819e9b4598845141067b281621874d0d5d7af9d8f7e00c1e54715b7d1e3",
            "client_id": "100067",
        }
        try:
            self.response = requests.post(self.url, headers=self.headers, data=self.dataa).json()
            self.Access_ToKen, self.Access_Uid = self.response['access_token'], self.response['open_id']
            time.sleep(0.2)
            print(f'{C}🔐 Login: {self.id}{RS}')
            return self.ToKen_GeneRaTe(self.Access_ToKen, self.Access_Uid)
        except Exception as e: 
            print(f"{R}❌ Login error {self.id}: {e}{RS}")
            time.sleep(10)
            return self.Guest_GeneRaTe(uid, password)
                                        
    def GeT_LoGin_PorTs(self, JwT_ToKen, PayLoad, dynamic_url="https://clientbp.ggpolarbear.com"):
        self.UrL = f'{dynamic_url}/GetLoginData'
        self.HeadErs = {
            'Expect': '100-continue',
            'Authorization': f'Bearer {JwT_ToKen}',
            'X-Unity-Version': '2022.3.47f1',
            'X-GA': 'v1 1',
            'ReleaseVersion': 'OB53',
            'Content-Type': 'application/x-www-form-urlencoded',
            'User-Agent': 'UnityPlayer/2022.3.47f1 (UnityWebRequest/1.0, libcurl/8.5.0-DEV)',
            'Connection': 'close',
            'Accept-Encoding': 'deflate, gzip',
        }        
        try:
            self.Res = requests.post(self.UrL, headers=self.HeadErs, data=PayLoad, verify=False)
            self.BesTo_data = json.loads(DeCode_PackEt(self.Res.content.hex()))  
            address, address2 = self.BesTo_data['32']['data'], self.BesTo_data['14']['data'] 
            ip, ip2 = address[:len(address) - 6], address2[:len(address2) - 6]
            port, port2 = address[len(address) - 5:], address2[len(address2) - 5:]             
            return ip, port, ip2, port2          
        except Exception as e:
            print(f"{R}❌ Failed to get ports from {self.UrL}: {e}{RS}")
        return None, None, None, None
        
    def ToKen_GeneRaTe(self, Access_ToKen, Access_Uid):
        self.UrL = "https://loginbp.ggwhitehawk.com/MajorLogin"
        self.HeadErs = {
            'X-Unity-Version': '2022.3.47f1',
            'ReleaseVersion': 'OB53',
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-GA': 'v1 1',
            'Content-Length': '928',
            'User-Agent': 'UnityPlayer/2022.3.47f1 (UnityWebRequest/1.0, libcurl/8.5.0-DEV)',
            'Host': 'loginbp.ggwhitehawk.com',
            'Connection': 'Keep-Alive',
            'Accept-Encoding': 'deflate, gzip'
        }   
        
        self.dT = bytes.fromhex('1a13323032352d31312d32362030313a35313a3238220966726565206669726528013a07312e3132332e314232416e64726f6964204f532039202f204150492d3238202850492f72656c2e636a772e32303232303531382e313134313333294a0848616e6468656c64520c4d544e2f537061636574656c5a045749464960800a68d00572033234307a2d7838362d3634205353453320535345342e3120535345342e32204156582041565832207c2032343030207c20348001e61e8a010f416472656e6f2028544d292036343092010d4f70656e474c20455320332e329a012b476f6f676c657c36323566373136662d393161372d343935622d396631362d303866653964336336353333a2010e3137362e32382e3133392e313835aa01026172b201203433303632343537393364653836646134323561353263616164663231656564ba010134c2010848616e6468656c64ca010d4f6e65506c7573204135303130ea014063363961653230386661643732373338623637346232383437623530613361316466613235643161313966616537343566633736616334613065343134633934f00101ca020c4d544e2f537061636574656cd2020457494649ca03203161633462383065636630343738613434323033626638666163363132306635e003b5ee02e8039a8002f003af13f80384078004a78f028804b5ee029004a78f029804b5ee02b00404c80401d2043d2f646174612f6170702f636f6d2e6474732e667265656669726574682d66705843537068495636644b43376a4c2d574f7952413d3d2f6c69622f61726de00401ea045f65363261623933353464386662356662303831646233333861636233333439317c2f646174612f6170702f636f6d2e6474732e667265656669726574682d66705843537068495636644b43376a4c2d574f7952413d3d2f626173652e61706bf00406f804018a050233329a050a32303139313139303236a80503b205094f70656e474c455332b805ff01c00504e005be7eea05093372645f7061727479f205704b717348543857393347646347335a6f7a454e6646775648746d377171316552554e6149444e67526f626f7a4942744c4f695943633459367a767670634943787a514632734f453463627974774c7334785a62526e70524d706d5752514b6d654f35766373386e51594268777148374bf805e7e4068806019006019a060134a2060134b2062213521146500e590349510e460900115843395f005b510f685b560a6107576d0f0366')
        
        self.dT = self.dT.replace(b'2026-07-30 14:11:20', str(datetime.now())[:-7].encode())        
        self.dT = self.dT.replace(b'c69ae208fad72738b674b2847b50a3a1dfa25d1a19fae745fc76ac4a0e414c94', Access_ToKen.encode())
        self.dT = self.dT.replace(b'4306245793de86da425a52caadf21eed', Access_Uid.encode())
        
        try:
            hex_data = self.dT.hex()
            encoded_data = EnC_AEs(hex_data)
            if not all(c in '0123456789abcdefABCDEF' for c in encoded_data):
                encoded_data = hex_data
            self.PaYload = bytes.fromhex(encoded_data)
        except Exception as e:
            print(f"{R}❌ Encoding error: {e}{RS}")
            self.PaYload = self.dT
        
        self.ResPonse = requests.post(self.UrL, headers=self.HeadErs, data=self.PaYload, verify=False)        
        if self.ResPonse.status_code == 200 and len(self.ResPonse.text) > 10:
            try:
                self.BesTo_data = json.loads(DeCode_PackEt(self.ResPonse.content.hex()))
                self.JwT_ToKen = self.BesTo_data['8']['data']           
                self.combined_timestamp, self.key, self.iv = self.GeT_Key_Iv(self.ResPonse.content)
                
                mlr = _pbF(self.ResPonse.content)
                dynamic_url = mlr[10].decode('utf-8') if 10 in mlr else 'https://clientbp.ggpolarbear.com'
                
                ip, port, ip2, port2 = self.GeT_LoGin_PorTs(self.JwT_ToKen, self.PaYload, dynamic_url)            
                return self.JwT_ToKen, self.key, self.iv, self.combined_timestamp, ip, port, ip2, port2
            except Exception as e:
                print(f"{R}❌ Response parsing error: {e}{RS}")
                time.sleep(5)
                return self.ToKen_GeneRaTe(Access_ToKen, Access_Uid)
        else:
            print(f"{R}❌ Token generation error, status: {self.ResPonse.status_code}{RS}")
            time.sleep(5)
            return self.ToKen_GeneRaTe(Access_ToKen, Access_Uid)
      
    def Get_FiNal_ToKen_0115(self):
        try:
            result = self.Guest_GeneRaTe(self.id, self.password)
            if not result:
                print(f"{Y}⚠️ Failed to get token {self.id}, retrying...{RS}")
                time.sleep(5)
                return self.Get_FiNal_ToKen_0115()
                
            token, key, iv, Timestamp, ip, port, ip2, port2 = result
            
            if not all([ip, port, ip2, port2]):
                print(f"{Y}⚠️ Failed to get ports {self.id}, retrying...{RS}")
                time.sleep(5)
                return self.Get_FiNal_ToKen_0115()
                
            self.JwT_ToKen = token        
            try:
                self.AfTer_DeC_JwT = jwt.decode(token, options={"verify_signature": False})
                self.AccounT_Uid = self.AfTer_DeC_JwT.get('account_id')
                self.EncoDed_AccounT = hex(self.AccounT_Uid)[2:]
                self.HeX_VaLue = DecodE_HeX(Timestamp)
                self.TimE_HEx = self.HeX_VaLue
                self.JwT_ToKen_ = token.encode().hex()
                print(f'{C}🆔 Account UID: {self.AccounT_Uid}{RS}')
            except Exception as e:
                print(f"{R}❌ Token decode error {self.id}: {e}{RS}")
                time.sleep(5)
                return self.Get_FiNal_ToKen_0115()
                
            try:
                self.Header = hex(len(EnC_PacKeT(self.JwT_ToKen_, key, iv)) // 2)[2:]
                length = len(self.EncoDed_AccounT)
                self.__ = '00000000'
                if length == 9: self.__ = '0000000'
                elif length == 8: self.__ = '00000000'
                elif length == 10: self.__ = '000000'
                elif length == 7: self.__ = '000000000'
                self.Header = f'0115{self.__}{self.EncoDed_AccounT}{self.TimE_HEx}00000{self.Header}'
                self.FiNal_ToKen_0115 = self.Header + EnC_PacKeT(self.JwT_ToKen_, key, iv)
            except Exception as e:
                print(f"{R}❌ Final token error {self.id}: {e}{RS}")
                time.sleep(5)
                return self.Get_FiNal_ToKen_0115()
                
            self.AutH_ToKen = self.FiNal_ToKen_0115
            self.Connect_SerVer(self.JwT_ToKen, self.AutH_ToKen, ip, port, key, iv, ip2, port2)        
            return self.AutH_ToKen, key, iv
            
        except Exception as e:
            print(f"{R}❌ {self.id} connection failed: {e}{RS}")
            time.sleep(10)
            return self.Get_FiNal_ToKen_0115()

# -------------------------------------------------------------------
# Account starter
# -------------------------------------------------------------------
def start_account(account):
    try:
        print(f"{C}🚀 Starting: {account['id']}{RS}")
        FF_CLient(account['id'], account['password'])
    except Exception as e:
        print(f"{R}❌ Error starting {account['id']}: {e}{RS}")
        time.sleep(5)
        start_account(account)

# -------------------------------------------------------------------
# Terminal input
# -------------------------------------------------------------------
def get_termux_input():
    print(f"\n{C}{'╔'}{'═'*48}{'╗'}{RS}")
    print(f"{C}{'║'}{RS}  {BOLD}⚡ POWER TOOL - TERMUX CONTROLLER ⚡{RS}     {C}{'║'}{RS}")
    print(f"{C}{'╚'}{'═'*48}{'╝'}{RS}\n")

    while True:
        try:
            target_uid = input(f"  {G}🎯 Enter Target UID{RS} : ").strip()
            if not target_uid or not target_uid.isdigit():
                print(f"  {R}❌ Invalid UID! Enter numbers only.{RS}")
                continue
            break
        except KeyboardInterrupt:
            print(f"\n{R}🛑 Cancelled.{RS}")
            sys.exit(0)

    while True:
        try:
            duration_input = input(f"  {Y}⏱️ Duration in minutes (0 = unlimited){RS} : ").strip()
            if not duration_input.isdigit():
                print(f"  {R}❌ Enter a valid number!{RS}")
                continue
            duration = int(duration_input)
            break
        except KeyboardInterrupt:
            print(f"\n{R}🛑 Cancelled.{RS}")
            sys.exit(0)

    duration_text = f"{duration} minutes" if duration > 0 else "Unlimited"
    print(f"\n  {G}✅ Target UID: {BOLD}{target_uid}{RS}")
    print(f"  {G}✅ Duration: {BOLD}{duration_text}{RS}\n")

    return target_uid, duration if duration > 0 else None

# -------------------------------------------------------------------
# Main entry point
# -------------------------------------------------------------------
def StarT_SerVer():
    os.system('clear' if os.name == 'posix' else 'cls')

    print(f"\n{C}{'='*50}{RS}")
    print(f"   {BOLD}🔥 POWER TOOL - LOADING...{RS}")
    print(f"{C}{'='*50}{RS}")
    print(f"{G}📦 Loaded {len(ACCOUNTS)} accounts from accs.txt{RS}")
    print(f"{C}{'='*50}{RS}\n")

    target_uid, duration_minutes = get_termux_input()

    threads = []
    for account in ACCOUNTS:
        thread = Thread(target=start_account, args=(account,))
        thread.daemon = True
        threads.append(thread)
        thread.start()
        time.sleep(2)

    print(f"\n{Y}⏳ Waiting for accounts to connect...{RS}")
    time.sleep(8)

    with connected_clients_lock:
        online_count = len(connected_clients)
        online_list = list(connected_clients.keys())
    
    print(f"\n{G}✅ Online accounts: {online_count}{RS}")
    if online_list:
        print(f"{G}📋 {online_list}{RS}")

    print(f"\n{G}🚀 Starting spam on UID: {BOLD}{target_uid}{RS}")
    start_power(target_uid, duration_minutes)

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print(f"\n{R}🛑 Stopping...{RS}")
        stop_power(target_uid)
        sys.exit(0)

if __name__ == "__main__":
    StarT_SerVer()